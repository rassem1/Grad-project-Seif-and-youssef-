#include "UltrasonicSensor.h"
#include "Defines.h"
#include <util/delay.h>
#include <avr/io.h>

#include <avr/interrupt.h>

// Helper functions to set/clear pins
static void Servo_SetAngle(uint8_t angle);
static uint16_t Ultrasonic_Read(void);

void UltrasonicSensor_Init(void) {
    // Setup pins
    TRIG_DDR |= (1 << TRIG_PIN);     // Output trigger pin
    ECHO_DDR &= ~(1 << ECHO_PIN);    // Input echo pin

    // Servo PWM init: Use Timer1, Fast PWM 50Hz (20ms period), OCR1A controls angle
    // Setup Timer1 for servo PWM
    SERVO_DDR |= (1 << SERVO_PIN);
    // Clear Timer1 config
    TCCR1A = 0;
    TCCR1B = 0;

    // Fast PWM, 10-bit, prescaler 64 (adjust as needed)
    TCCR1A |= (1 << COM1A1) | (1 << WGM11);
    TCCR1B |= (1 << WGM13) | (1 << WGM12) | (1 << CS11) | (1 << CS10);

    // Set ICR1 for 20ms period: Assuming 16MHz clock,
    // F_pwm = F_CPU / (prescaler * (1 + ICR1))
    // ICR1 = 4999 for 50Hz (20ms)
    ICR1 = 4999;

    // Center servo at 90 degrees
    Servo_SetAngle(90);
    _delay_ms(1000);
}

uint16_t UltrasonicSensor_ReadDistance(void) {
    return Ultrasonic_Read();
}

uint16_t UltrasonicSensor_LookRight(void) {
    Servo_SetAngle(0);   // turn servo to right
    _delay_ms(500);
    uint16_t dist = Ultrasonic_Read();
    _delay_ms(100);
    Servo_SetAngle(90);  // return center
    _delay_ms(300);
    return dist;
}

uint16_t UltrasonicSensor_LookLeft(void) {
    Servo_SetAngle(180); // turn servo to left
    _delay_ms(500);
    uint16_t dist = Ultrasonic_Read();
    _delay_ms(100);
    Servo_SetAngle(90);  // return center
    _delay_ms(300);
    return dist;
}

// -- Private functions --

static void Servo_SetAngle(uint8_t angle) {
    // Convert angle 0-180 to OCR1A compare value (servo pulse width)
    // Servo pulse width typically from 1ms (0°) to 2ms (180°)
    // OCR1A = (pulse width / period) * ICR1
    // 1ms pulse: OCR1A = (1ms / 20ms)*4999 ≈ 250
    // 2ms pulse: OCR1A = (2ms / 20ms)*4999 ≈ 500
    uint16_t ocr_value = ((uint32_t)angle * 250) / 180 + 250;
    OCR1A = ocr_value;
}

static uint16_t Ultrasonic_Read(void) {
    // Send 10us pulse on TRIG
    TRIG_PORT &= ~(1 << TRIG_PIN);
    _delay_us(2);
    TRIG_PORT |= (1 << TRIG_PIN);
    _delay_us(10);
    TRIG_PORT &= ~(1 << TRIG_PIN);

    // Wait for ECHO pin to go HIGH, then measure duration
    uint32_t count = 0;

    // Wait for echo HIGH with timeout
    uint32_t timeout = 30000; // about 30 ms
    while (!(ECHO_PORT & (1 << ECHO_PIN))) {
        if (count++ > timeout) return 0;
        _delay_us(1);
    }

    // Measure how long echo stays HIGH
    count = 0;
    while (ECHO_PORT & (1 << ECHO_PIN)) {
        if (count++ > timeout) break;
        _delay_us(1);
    }

    // Distance in cm = (duration in us) * speed of sound (0.034 cm/us) / 2
    // count is microseconds approx
    uint16_t distance_cm = (count * 0.034) / 2;
    if (distance_cm == 0 || distance_cm > 200) distance_cm = 250;

    return distance_cm;
}
