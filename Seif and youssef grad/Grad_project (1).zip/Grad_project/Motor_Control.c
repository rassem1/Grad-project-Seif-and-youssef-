#include "MotorControl.h"
#include "Defines.h"
#include <util/delay.h>

static void MotorControl_SetPin(uint8_t portPin, uint8_t state);

void MotorControl_Init(void) {
    // Set motor pins as output
    LEFT_MOTOR_FWD_DDR |= (1 << LEFT_MOTOR_FWD_PIN);
    LEFT_MOTOR_BWD_DDR |= (1 << LEFT_MOTOR_BWD_PIN);
    RIGHT_MOTOR_FWD_DDR |= (1 << RIGHT_MOTOR_FWD_PIN);
    RIGHT_MOTOR_BWD_DDR |= (1 << RIGHT_MOTOR_BWD_PIN);
    ENA_DDR |= (1 << ENA_PIN);
    ENB_DDR |= (1 << ENB_PIN);

    // Stop motors initially
    MotorControl_Stop();
}

void MotorControl_MoveForward(void) {
    // Left motor forward
    LEFT_MOTOR_FWD_PORT |= (1 << LEFT_MOTOR_FWD_PIN);
    LEFT_MOTOR_BWD_PORT &= ~(1 << LEFT_MOTOR_BWD_PIN);

    // Right motor forward
    RIGHT_MOTOR_FWD_PORT |= (1 << RIGHT_MOTOR_FWD_PIN);
    RIGHT_MOTOR_BWD_PORT &= ~(1 << RIGHT_MOTOR_BWD_PIN);

    // Enable motors (assuming HIGH enables)
    ENA_PORT |= (1 << ENA_PIN);
    ENB_PORT |= (1 << ENB_PIN);
}

void MotorControl_MoveBackward(void) {
    LEFT_MOTOR_FWD_PORT &= ~(1 << LEFT_MOTOR_FWD_PIN);
    LEFT_MOTOR_BWD_PORT |= (1 << LEFT_MOTOR_BWD_PIN);

    RIGHT_MOTOR_FWD_PORT &= ~(1 << RIGHT_MOTOR_FWD_PIN);
    RIGHT_MOTOR_BWD_PORT |= (1 << RIGHT_MOTOR_BWD_PIN);

    ENA_PORT |= (1 << ENA_PIN);
    ENB_PORT |= (1 << ENB_PIN);
}

void MotorControl_Stop(void) {
    LEFT_MOTOR_FWD_PORT &= ~(1 << LEFT_MOTOR_FWD_PIN);
    LEFT_MOTOR_BWD_PORT &= ~(1 << LEFT_MOTOR_BWD_PIN);

    RIGHT_MOTOR_FWD_PORT &= ~(1 << RIGHT_MOTOR_FWD_PIN);
    RIGHT_MOTOR_BWD_PORT &= ~(1 << RIGHT_MOTOR_BWD_PIN);

    ENA_PORT |= (1 << ENA_PIN);
    ENB_PORT |= (1 << ENB_PIN);
}

void MotorControl_TurnRight(void) {
    LEFT_MOTOR_FWD_PORT |= (1 << LEFT_MOTOR_FWD_PIN);
    LEFT_MOTOR_BWD_PORT &= ~(1 << LEFT_MOTOR_BWD_PIN);

    RIGHT_MOTOR_FWD_PORT &= ~(1 << RIGHT_MOTOR_FWD_PIN);
    RIGHT_MOTOR_BWD_PORT |= (1 << RIGHT_MOTOR_BWD_PIN);

    ENA_PORT |= (1 << ENA_PIN);
    ENB_PORT |= (1 << ENB_PIN);

    _delay_ms(700);
}

void MotorControl_TurnLeft(void) {
    LEFT_MOTOR_FWD_PORT &= ~(1 << LEFT_MOTOR_FWD_PIN);
    LEFT_MOTOR_BWD_PORT |= (1 << LEFT_MOTOR_BWD_PIN);

    RIGHT_MOTOR_FWD_PORT |= (1 << RIGHT_MOTOR_FWD_PIN);
    RIGHT_MOTOR_BWD_PORT &= ~(1 << RIGHT_MOTOR_BWD_PIN);

    ENA_PORT |= (1 << ENA_PIN);
    ENB_PORT |= (1 << ENB_PIN);

    _delay_ms(700);
}
