#ifndef MOTORCONTROL_H
#define MOTORCONTROL_H

#include <stdint.h>

void MotorControl_Init(void);
void MotorControl_MoveForward(void);
void MotorControl_MoveBackward(void);
void MotorControl_Stop(void);
void MotorControl_TurnRight(void);
void MotorControl_TurnLeft(void);

#endif