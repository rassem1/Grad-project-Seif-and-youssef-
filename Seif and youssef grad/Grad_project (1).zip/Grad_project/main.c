#include <avr/io.h>
#include <util/delay.h>
#include "MotorControl.h"
#include "UltrasonicSensor.h"
#include "Defines.h"

int main(void) {
    uint16_t distance = 100;
    uint16_t rightDist = 0;
    uint16_t leftDist = 0;

    MotorControl_Init();
    UltrasonicSensor_Init();

    while(1) {
        _delay_ms(50);
        distance = UltrasonicSensor_ReadDistance();

        if (distance <= DISTANCE_THRESHOLD) {
            MotorControl_Stop();
            _delay_ms(300);

            MotorControl_MoveBackward();
            _delay_ms(500);

            MotorControl_Stop();
            _delay_ms(300);

            rightDist = UltrasonicSensor_LookRight();
            leftDist = UltrasonicSensor_LookLeft();

            if ((rightDist > DISTANCE_THRESHOLD) && (rightDist >= leftDist)) {
                MotorControl_TurnRight();
            } else if (leftDist > DISTANCE_THRESHOLD) {
                MotorControl_TurnLeft();
            } else {
                MotorControl_MoveBackward();
                _delay_ms(700);
                MotorControl_TurnRight();
            }
        } else {
            MotorControl_MoveForward();
        }
    }
    return 0;
}
