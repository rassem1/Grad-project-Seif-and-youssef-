#ifndef ULTRASONICSENSOR_H
#define ULTRASONICSENSOR_H

#include <stdint.h>

void UltrasonicSensor_Init(void);
uint16_t UltrasonicSensor_ReadDistance(void);
uint16_t UltrasonicSensor_LookRight(void);
uint16_t UltrasonicSensor_LookLeft(void);

#endif
