#ifndef DEFINES_H
#define DEFINES_H

#include <avr/io.h>

// Motor pins (adjust to your MCU and wiring)
#define LEFT_MOTOR_FWD_PORT   PORTD
#define LEFT_MOTOR_FWD_DDR    DDRD
#define LEFT_MOTOR_FWD_PIN    PD5

#define LEFT_MOTOR_BWD_PORT   PORTD
#define LEFT_MOTOR_BWD_DDR    DDRD
#define LEFT_MOTOR_BWD_PIN    PD6

#define RIGHT_MOTOR_FWD_PORT  PORTD
#define RIGHT_MOTOR_FWD_DDR   DDRD
#define RIGHT_MOTOR_FWD_PIN   PD4

#define RIGHT_MOTOR_BWD_PORT  PORTD
#define RIGHT_MOTOR_BWD_DDR   DDRD
#define RIGHT_MOTOR_BWD_PIN   PD3

#define ENA_PORT             PORTB
#define ENA_DDR              DDRB
#define ENA_PIN              PB7

#define ENB_PORT             PORTB
#define ENB_DDR              DDRB
#define ENB_PIN              PB0

// Ultrasonic sensor pins
#define TRIG_PORT            PORTB
#define TRIG_DDR             DDRB
#define TRIG_PIN             PB1

#define ECHO_PORT            PINC
#define ECHO_DDR             DDRC
#define ECHO_PIN             PC0

// Servo PWM pin (e.g., OC1A)
#define SERVO_DDR            DDRB
#define SERVO_PORT           PORTB
#define SERVO_PIN            PB2

#define DISTANCE_THRESHOLD   30  // cm

#endif